import pandas as pd
import joblib
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

ROOT = Path(__file__).resolve().parent
data = pd.read_csv(ROOT / "dataset" / "student_data.csv")
features = ["study_hours", "attendance", "previous_score", "assignment_score", "internal_marks"]
X, y = data[features], data["performance"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s = scaler.transform(X_test)
model = RandomForestClassifier(n_estimators=180, max_depth=8, random_state=42, class_weight="balanced")
model.fit(X_train_s, y_train)
pred = model.predict(X_test_s)
print("Test accuracy:", round(accuracy_score(y_test, pred)*100, 2), "%")
print(classification_report(y_test, pred))
joblib.dump(model, ROOT / "model" / "student_performance_model.pkl")
joblib.dump(scaler, ROOT / "model" / "scaler.pkl")
print("Saved model and scaler.")
