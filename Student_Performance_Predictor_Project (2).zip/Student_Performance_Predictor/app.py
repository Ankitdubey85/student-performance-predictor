from flask import Flask, render_template, request
import joblib
import numpy as np
from pathlib import Path

app = Flask(__name__)
ROOT = Path(__file__).resolve().parent
model = joblib.load(ROOT / "model" / "student_performance_model.pkl")
scaler = joblib.load(ROOT / "model" / "scaler.pkl")

FEATURES = ["study_hours", "attendance", "previous_score", "assignment_score", "internal_marks"]

@app.route("/", methods=["GET", "POST"])
def home():
    result = None
    values = {}
    if request.method == "POST":
        try:
            values = {k: float(request.form[k]) for k in FEATURES}
            row = np.array([[values[k] for k in FEATURES]])
            prediction = model.predict(scaler.transform(row))[0]
            confidence = float(max(model.predict_proba(scaler.transform(row))[0]) * 100)
            tips = {
                "Excellent": "Keep your routine consistent and challenge yourself with advanced topics.",
                "Good": "Maintain your study schedule and revise weak areas regularly.",
                "Average": "Increase focused study time and practice assignments consistently.",
                "At Risk": "Create a support plan: attend classes, ask for help, and set small weekly goals."
            }
            result = {"label": prediction, "confidence": round(confidence, 1), "tip": tips[prediction]}
        except (ValueError, KeyError):
            result = {"label": "Invalid input", "confidence": 0, "tip": "Please enter valid numeric values."}
    return render_template("index.html", result=result, values=values)

if __name__ == "__main__":
    import os
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
