# Student Performance Predictor

## Project
A small Flask + Machine Learning demo that predicts a student's performance category from academic indicators.

## Features
- Study hours, attendance, previous score, assignment score and internal marks as input
- Random Forest classifier
- StandardScaler preprocessing
- Prediction categories: Excellent, Good, Average, At Risk
- Simple responsive web interface
- Synthetic demonstration dataset (500 rows)

## Setup (Windows / VS Code)
1. Open this folder in VS Code.
2. In Terminal run: `py -m venv .venv`
3. Activate: `.venv\\Scripts\\activate`
4. Install: `pip install -r requirements.txt`
5. Run: `python app.py`
6. Open browser: http://127.0.0.1:5000

## Retraining
Run: `python train_model.py`

## Dataset note
The included CSV is synthetic, generated for demonstration and testing. The displayed accuracy (on a held-out test split) is not a real-world performance claim. Use a real, representative and consented dataset before deployment.

## Deploy on Render
1. Push this project to GitHub.
2. Render Dashboard → New → Web Service → select your repository.
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app --bind 0.0.0.0:$PORT`
5. Choose Free plan and Deploy.

A `render.yaml` file is included for deployment configuration.
